export default function Dummy(){
    return(
        <h1>Hi dummy</h1>
    )
}